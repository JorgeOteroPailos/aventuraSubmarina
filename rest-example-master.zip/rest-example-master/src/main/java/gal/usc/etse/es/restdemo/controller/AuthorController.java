package gal.usc.etse.es.restdemo.controller;

import gal.usc.etse.es.restdemo.model.dto.Author;
import org.springframework.hateoas.server.ExposesResourceFor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("authors")
@ExposesResourceFor(Author.class)
public class AuthorController {
    @GetMapping("{id}")
    public Author get(@PathVariable String id) {
        return new Author(id, id);
    }
}
