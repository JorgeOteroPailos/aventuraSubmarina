package gal.usc.etse.es.restdemo.model.entity;

import jakarta.persistence.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@SuppressWarnings("unused")
@Entity
@Table(name = "books")
public class Book {
    @Id
    @Size(min=14, max=14)
    @Pattern(regexp = "\\d{3}-\\d{10}", message = "ISBN must follow pattern XXX-XXXXXXXXX")
    private String isbn;

    @Column
    @NotBlank
    private String title;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "author_id")
    @Valid
    private Author author;

    @Column
    private String editor;

    @Column
    @NotBlank
    private String edition;

    @Column(length = 100000)
    @NotBlank
    @Size(min = 1, max = 100000)
    private String summary;

    @Column
    @Size(min=2, max=2)
    private String language;

    public static Book from(gal.usc.etse.es.restdemo.model.dto.Book book) {
        return new Book(
                book.isbn(),
                book.title(),
                Author.from(book.author()),
                book.editor(),
                book.edition(),
                book.summary(),
                book.language()
        );
    }

    public Book() {}

    public Book(String isbn, String title, Author author, String editor, String edition, String summary, String language) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.editor = editor;
        this.edition = edition;
        this.summary = summary;
        this.language = language;
    }

    public String getTitle() {
        return title;
    }

    public Book setTitle(String title) {
        this.title = title;
        return this;
    }

    public Author getAuthor() {
        return author;
    }

    public Book setAuthor(Author author) {
        this.author = author;
        return this;
    }

    public String getEditor() {
        return editor;
    }

    public Book setEditor(String editor) {
        this.editor = editor;
        return this;
    }

    public String getEdition() {
        return edition;
    }

    public Book setEdition(String edition) {
        this.edition = edition;
        return this;
    }

    public String getSummary() {
        return summary;
    }

    public Book setSummary(String summary) {
        this.summary = summary;
        return this;
    }

    public String getLanguage() {
        return language;
    }

    public Book setLanguage(String language) {
        this.language = language;
        return this;
    }

    public String getIsbn() {
        return isbn;
    }

    public Book setIsbn(String isbn) {
        this.isbn = isbn;
        return this;
    }
}
