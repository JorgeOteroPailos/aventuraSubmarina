package gal.usc.etse.es.restdemo.service;

import gal.usc.etse.es.restdemo.exception.DuplicateUserException;
import gal.usc.etse.es.restdemo.model.entity.Role;
import gal.usc.etse.es.restdemo.model.dto.User;
import gal.usc.etse.es.restdemo.repository.RoleRepository;
import gal.usc.etse.es.restdemo.repository.UserRepository;
import org.jspecify.annotations.NullMarked;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@NullMarked
public class UserService implements UserDetailsService {
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public UserService(UserRepository userRepository, RoleRepository roleRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public gal.usc.etse.es.restdemo.model.entity.User loadUserByUsername(String username) throws UsernameNotFoundException {
        return userRepository.findByUsername(username).orElseThrow(() -> new UsernameNotFoundException(username));
    }

    public List<User> get() {
        return userRepository.findAll().stream().map(User::from).toList();
    }

    public Page<User> get(PageRequest page) {
        return userRepository.findAll(page).map(User::from);
    }

    public User get(String username){
        return User.from(loadUserByUsername(username));
    }

    public User create(User user) throws DuplicateUserException {
        var dbUser = userRepository.findByUsername(user.username());
        if (dbUser.isPresent()) {
            throw new DuplicateUserException(dbUser.get());
        }

        Role userRole = roleRepository.findByRolename("USER");

        return User.from(userRepository.save(
               gal.usc.etse.es.restdemo.model.entity.User.from(user, passwordEncoder).addRole(userRole)
        ));
    }
}
