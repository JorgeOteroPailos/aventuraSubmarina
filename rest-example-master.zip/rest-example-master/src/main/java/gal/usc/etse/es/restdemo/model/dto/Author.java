package gal.usc.etse.es.restdemo.model.dto;

public record Author (
        String id,
        String name
) {
    public static Author from(gal.usc.etse.es.restdemo.model.entity.Author author) {
        return new Author(
                author.getId(),
                author.getName()
        );
    }
}
