package gal.usc.etse.es.restdemo.service;

import gal.usc.etse.es.restdemo.exception.BookNotFoundException;
import gal.usc.etse.es.restdemo.exception.DuplicatedBookException;
import gal.usc.etse.es.restdemo.model.dto.Book;
import gal.usc.etse.es.restdemo.model.entity.Author;
import gal.usc.etse.es.restdemo.repository.BookRepository;
import gal.usc.etse.es.utils.patch.JsonPatch;
import gal.usc.etse.es.utils.patch.JsonPatchOperation;
import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import tools.jackson.databind.JsonNode;
import org.springframework.data.domain.Page;
import tools.jackson.databind.json.JsonMapper;

import java.util.*;

@Service
@NullMarked
public class BookService {
    private final BookRepository library;
    private final JsonMapper mapper;

    @Autowired
    public BookService(BookRepository library, JsonMapper mapper) {
        this.library = library;
        this.mapper = mapper;
    }

    public Book addBook(Book book) throws DuplicatedBookException {
        if (!library.existsById(book.isbn())) {
            library.save(gal.usc.etse.es.restdemo.model.entity.Book.from(book));
            return book;
        } else {
            throw new DuplicatedBookException(book);
        }
    }

    public Page<Book> getBooks(@Nullable String author, PageRequest page) {
        return library.findAll(Example.of(new gal.usc.etse.es.restdemo.model.entity.Book().setAuthor(new Author().setName(author))), page)
                .map(Book::from);
    }

    public Book getBook(String isbn) throws BookNotFoundException {
        return library.findById(isbn).map(Book::from).orElseThrow(() -> new BookNotFoundException(isbn));
    }

    public Book updateBook(String isbn, List<JsonPatchOperation> changes) throws BookNotFoundException {
        Book book = library.findById(isbn).map(Book::from).orElseThrow(() -> new BookNotFoundException(isbn));
        JsonNode patched = JsonPatch.apply(changes, mapper.convertValue(book, JsonNode.class));
        Book updated = mapper.convertValue(patched, Book.class);
        return Book.from(library.save(gal.usc.etse.es.restdemo.model.entity.Book.from(updated)));
    }
}
