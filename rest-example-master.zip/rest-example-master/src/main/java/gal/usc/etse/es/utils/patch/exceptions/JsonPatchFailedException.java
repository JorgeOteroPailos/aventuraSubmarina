package gal.usc.etse.es.utils.patch.exceptions;

public class JsonPatchFailedException extends RuntimeException {
    public JsonPatchFailedException(String message) {
        super(message);
    }
}
