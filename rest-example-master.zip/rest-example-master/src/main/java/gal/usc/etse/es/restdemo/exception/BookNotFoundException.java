package gal.usc.etse.es.restdemo.exception;

public class BookNotFoundException extends Exception {
    private final String isbn;

    public BookNotFoundException(String isbn) {
        this.isbn = isbn;
    }

    public String getISBN() {
        return isbn;
    }
}
