package gal.usc.etse.es.restdemo.model.dto;

import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.hateoas.server.core.Relation;

@Relation(collectionRelation = "books")
public record Book (
    @JsonView(Views.Summary.class) String isbn,
    @JsonView(Views.Summary.class) String title,
    @JsonView(Views.Summary.class) Author author,
    @JsonView(Views.Complete.class) String editor,
    @JsonView(Views.Complete.class) String edition,
    @JsonView(Views.Complete.class) String summary,
    @JsonView(Views.Complete.class) String language
) {
    public interface Views {
        interface Summary {}
        interface Complete extends Summary {}
    }

    public static Book from(gal.usc.etse.es.restdemo.model.entity.Book book) {
        return new Book(
                book.getIsbn(),
                book.getTitle(),
                Author.from(book.getAuthor()),
                book.getEditor(),
                book.getEdition(),
                book.getSummary(),
                book.getLanguage()
        );
    }
}
