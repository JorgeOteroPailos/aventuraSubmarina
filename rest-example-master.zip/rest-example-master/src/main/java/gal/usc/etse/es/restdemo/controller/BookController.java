package gal.usc.etse.es.restdemo.controller;

import com.fasterxml.jackson.annotation.JsonView;
import gal.usc.etse.es.restdemo.exception.BookNotFoundException;
import gal.usc.etse.es.restdemo.exception.DuplicatedBookException;
import gal.usc.etse.es.restdemo.model.dto.Author;
import gal.usc.etse.es.restdemo.model.dto.Book;
import gal.usc.etse.es.restdemo.service.BookService;
import gal.usc.etse.es.utils.patch.JsonPatchOperation;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.jspecify.annotations.NullMarked;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.hateoas.*;
import org.springframework.hateoas.server.EntityLinks;
import org.springframework.hateoas.server.ExposesResourceFor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@NullMarked
@RestController
@RequestMapping("books")
@ExposesResourceFor(Book.class)
@Tag(name = "books-controller", description = "Books related operations")
public class BookController {
    private final BookService bookService;
    private final EntityLinks entityLinks;

    @Autowired
    public BookController(BookService bookService, EntityLinks entityLinks) {
        this.bookService = bookService;
        this.entityLinks = entityLinks;
    }

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @JsonView(Book.Views.Summary.class)
    @PreAuthorize("hasAuthority('books:read')")
    @Operation(description = "Get all books")
    public ResponseEntity<PagedModel<Book>> get(
            @Parameter(description = "Author name for filtering. The filtering is applied using exact matches", example = "Miguel de Cervantes")
            @RequestParam(value = "author", required = false) String author,
            @Parameter(description = "The number of the page that the service will retrieve from the database", example = "1")
            @RequestParam(value = "page", required = false, defaultValue = "0") int page,
            @Parameter(description = "The size of the pages", example = "3")
            @RequestParam(value = "size", required = false, defaultValue = "10") int pagesize,
            @Parameter(description = "The criteria for sorting the items in the database. -attribute sorts descending by attribute. +attribute sorts ascending.", example="-isbn,+editor")
            @RequestParam(value = "sort", required = false, defaultValue = "") List<String> sort
    ) {
        var books = bookService.getBooks(
                author,
                PageRequest.of(
                        page,
                        pagesize,
                        Sort.by(sort.stream().map(key -> key.startsWith("-") ? Sort.Order.desc(key.substring(1)) : Sort.Order.asc(key)).toList())
                )
        );

        PagedModel<Book> response = PagedModel.of(books.getContent(), new PagedModel.PageMetadata(books.getSize(), books.getNumber(), books.getTotalElements(), books.getTotalPages()));

        response.add(entityLinks.linkToCollectionResource(Book.class).withSelfRel());
        response.add(linkTo(methodOn(BookController.class).get(author, page + 1, pagesize, sort)).withRel(IanaLinkRelations.NEXT));
        response.add(linkTo(methodOn(BookController.class).get(author, page - 1, pagesize, sort)).withRel(IanaLinkRelations.PREVIOUS));
        response.add(linkTo(methodOn(BookController.class).get(author, 0, pagesize, sort)).withRel(IanaLinkRelations.FIRST));
        response.add(linkTo(methodOn(BookController.class).get(author, books.getTotalPages() - 1, pagesize, sort)).withRel(IanaLinkRelations.LAST));

        return ResponseEntity.ok(response);
    }

    @GetMapping(
            path = "{isbn}",
            produces = MediaTypes.HAL_JSON_VALUE
    )
    @PreAuthorize("permitAll()")
    @JsonView(Book.Views.Complete.class)
    public ResponseEntity<EntityModel<Book>> get(@PathVariable("isbn") String isbn) throws BookNotFoundException {
        EntityModel<Book> book = EntityModel.of(bookService.getBook(isbn));

        book.add(entityLinks.linkToItemResource(Book.class, isbn).withSelfRel());
        book.add(entityLinks.linkToItemResource(Author.class, book.getContent().author().id()).withRel(IanaLinkRelations.AUTHOR));
        book.add(entityLinks.linkToCollectionResource(Book.class).withRel(IanaLinkRelations.COLLECTION));

        return ResponseEntity.ok(
                book
        );
    }

    @PostMapping(
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaTypes.HAL_JSON_VALUE
    )
    @PreAuthorize("hasAuthority('books:create')")
    public ResponseEntity<Book> add(@RequestBody @Valid Book book) throws DuplicatedBookException {
        book = bookService.addBook(book);

        return ResponseEntity
                .created(MvcUriComponentsBuilder.fromMethodName(BookController.class, "getBook", book.isbn()).build().toUri())
                .body(book);
    }

    @PatchMapping(
            path = "{isbn}",
            consumes = "application/json-patch+json",
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    @PreAuthorize("hasAuthority('books:update')")
    public ResponseEntity<Book> update(@PathVariable("isbn") String isbn, @RequestBody List<JsonPatchOperation> changes) throws BookNotFoundException {
        return ResponseEntity.ok(bookService.updateBook(isbn, changes));
    }
}
