package gal.usc.etse.es.restdemo.exception;

import gal.usc.etse.es.restdemo.model.dto.Book;

public class DuplicatedBookException extends Exception {
    private final Book book;

    public DuplicatedBookException(Book book) {
        this.book = book;
    }

    public Book getBook() {
        return book;
    }
}
