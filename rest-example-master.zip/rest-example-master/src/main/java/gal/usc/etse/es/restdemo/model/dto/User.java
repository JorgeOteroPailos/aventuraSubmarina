package gal.usc.etse.es.restdemo.model.dto;

import com.fasterxml.jackson.annotation.JsonView;
import gal.usc.etse.es.restdemo.model.entity.Role;

import java.util.Set;
import java.util.stream.Collectors;

public record User (
        @JsonView(Views.Public.class)
        String username,
        @JsonView(Views.Private.class)
        String password,
        @JsonView(Views.Private.class)
        Set<String> roles
) {
    public static User from(gal.usc.etse.es.restdemo.model.entity.User user) {
        return new User(user.getUsername(), user.getPassword(), user.getRoles().stream().map(Role::getRolename).collect(Collectors.toSet()));
    }

    public interface Views {
        interface Public {}
        interface Private extends Public {}
    }
}
