TRUNCATE books CASCADE;

INSERT INTO books(isbn, title, author_id, editor, edition, summary, language) VALUES (
    '978-0544003415',
    'The Lord of the Rings',
    'JRRT',
    'William Morrow Paperbacks',
    '50th Anniversary',
    'One Ring to rule them all, One Ring to find them, One Ring to bring them all and in the darkness bind them.',
    'en'
), (
    '978-0486406510',
    'A Tale of Two Cities',
    'ChDi',
    'Dover Publications Inc.',
    'Unabridged',
    'It was the time of the French Revolution a time of great change and great danger.',
    'en'
), (
    '978-2075155540',
    'Le Petit Prince',
    'AdSE',
    'Gallimard jeunesse',
    'Illustrated - Special',
    'Le premier soir, je me suis donc endormi sur le sable à mille milles de toute terre habitée.',
    'fr'
), (
    '978-8420412146',
    'Don Quijote de la Mancha',
    'MdCS',
    'RAE',
    'Edición conmemorativa de la RAE y la ASALE',
    'Una de las novelas más importantes de todos los tiempos y para muchos la obra definitiva de la literatura española.',
    'es'
), (
    '978-9722524223',
    'O Alquimista',
    'PaCo',
    'Bertrand Editora',
    '2014',
    'Quando uma pessoa realmente deseja algo, todo o universo conspira para que você possa realizar seu sonho.',
    'pt'
), (
    '978-8845296833',
    'Il nome della rosa',
    'UmEc',
    'Bompiani',
    'I',
    'Ultima settimana del novembre 1327. Il novizio Adso da Melk accompagna in un''abbazia dell''alta Italia frate Guglielmo da Baskerville, incaricato di una sottile e imprecisa missione diplomatica.',
    'it'
);