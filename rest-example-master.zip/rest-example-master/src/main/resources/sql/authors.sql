TRUNCATE authors CASCADE;

INSERT INTO authors(id, name) VALUES
('JRRT', 'J.R.R. Tolkien'),
('ChDi', 'Charles Dickens'),
('AdSE', 'Antoine de Saint-Exupéry'),
('MdCS', 'Miguel de Cervantes'),
('PaCo', 'Paulo Coelho'),
('UmEc', 'Umberto Eco');
